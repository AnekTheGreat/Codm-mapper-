package com.anek.mapper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = Config.prefs(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }

        fun label(t: String) = TextView(this).apply { text = t; textSize = 16f; setPadding(0, 32, 0, 8) }
        fun slider(key: String, def: Int, max: Int) = SeekBar(this).apply {
            this.max = max; progress = p.getInt(key, def)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, v: Int, u: Boolean) { p.edit().putInt(key, v).apply() }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }

        root.addView(TextView(this).apply { text = "CODM Mapper"; textSize = 24f })
        root.addView(Switch(this).apply {
            text = "Mapper enabled"; isChecked = p.getBoolean("enabled", true)
            setOnCheckedChangeListener { _, c -> p.edit().putBoolean("enabled", c).apply() }
        })
        root.addView(label("Camera sensitivity"))
        root.addView(slider("sens", 50, 100))
        root.addView(label("Stick deadzone (%)"))
        root.addView(slider("dz", 10, 40))
        root.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            textSize = 14f; setPadding(0, 32, 0, 0)
            text = "1. Enable \"CODM Mapper\" in Accessibility.\n" +
                "2. In CODM, turn off its built-in controller support so inputs don't double up.\n" +
                "3. Button/zone positions are in Config.kt - edit them to match your HUD layout."
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
