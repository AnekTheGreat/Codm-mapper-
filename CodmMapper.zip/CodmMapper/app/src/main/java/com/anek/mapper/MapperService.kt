package com.anek.mapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.accessibility.AccessibilityEvent
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

class MapperService : AccessibilityService() {

    private class Slot {
        var stroke: StrokeDescription? = null
        var end: PointF? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val moveSlot = Slot()
    private val lookSlot = Slot()
    private var lookAnchor: Pt? = null // null = free look zone, else fire/ADS button
    private val btnSlots = HashMap<Pt, Slot>()

    private var w = 1920f
    private var h = 1080f
    private var fgPackage: String? = null
    private var inFlight = false
    private var gen = 0

    private var lx = 0f; private var ly = 0f
    private var rx = 0f; private var ry = 0f
    private val pressed = HashSet<Int>()

    private val logLines = ArrayDeque<String>()
    private var lastMotionLog = 0L

    private val keyMap: Map<Int, Pt> = mapOf(
        KeyEvent.KEYCODE_BUTTON_R2 to Config.FIRE,
        KeyEvent.KEYCODE_BUTTON_R1 to Config.FIRE,
        Config.AXIS_R_TRIGGER to Config.FIRE,
        KeyEvent.KEYCODE_BUTTON_L2 to Config.ADS,
        KeyEvent.KEYCODE_BUTTON_L1 to Config.ADS,
        Config.AXIS_L_TRIGGER to Config.ADS,
        KeyEvent.KEYCODE_BUTTON_A to Config.JUMP,
        KeyEvent.KEYCODE_BUTTON_B to Config.CROUCH,
        KeyEvent.KEYCODE_BUTTON_X to Config.RELOAD,
        KeyEvent.KEYCODE_BUTTON_Y to Config.SWAP
    )

    // If a gesture never reports back, don't stay frozen: reset and carry on.
    private val watchdog = Runnable { gen++; inFlight = false; resetSlots(); pump() }

    override fun onServiceConnected() {
        val dm = resources.displayMetrics
        w = max(dm.widthPixels, dm.heightPixels).toFloat()
        h = min(dm.widthPixels, dm.heightPixels).toFloat()
        if (Build.VERSION.SDK_INT >= 34) {
            serviceInfo = serviceInfo.apply { motionEventSources = InputDevice.SOURCE_JOYSTICK }
        }
        log("service connected")
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == "com.android.systemui") return
        if (pkg != fgPackage) log("fg $pkg")
        fgPackage = pkg
        if (!active()) releaseAll()
    }

    override fun onInterrupt() { releaseAll() }

    private fun active() =
        Config.prefs(this).getBoolean("enabled", true) && fgPackage in Config.CODM_PACKAGES

    private fun log(s: String) {
        logLines.addLast(s)
        while (logLines.size > 10) logLines.removeFirst()
        Config.prefs(this).edit().putString("log", logLines.joinToString("\n")).apply()
    }

    // ---------- input ----------

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.repeatCount == 0 && (e.action == KeyEvent.ACTION_DOWN || e.action == KeyEvent.ACTION_UP)) {
            log(KeyEvent.keyCodeToString(e.keyCode).removePrefix("KEYCODE_") +
                (if (e.action == KeyEvent.ACTION_DOWN) " down" else " up") +
                (if (active()) "" else " (inactive)"))
        }
        if (!active()) return false
        if (e.keyCode !in keyMap) return false
        if (e.action == KeyEvent.ACTION_DOWN) pressed.add(e.keyCode)
        else if (e.action == KeyEvent.ACTION_UP) pressed.remove(e.keyCode)
        pump()
        return true
    }

    // API 34+: sticks arrive as joystick motion events.
    override fun onMotionEvent(event: MotionEvent) {
        if (event.source and InputDevice.SOURCE_JOYSTICK == 0) return
        val x = event.getAxisValue(MotionEvent.AXIS_X)
        val y = event.getAxisValue(MotionEvent.AXIS_Y)
        var zx = event.getAxisValue(MotionEvent.AXIS_Z)
        var zy = event.getAxisValue(MotionEvent.AXIS_RZ)
        if (hypot(zx, zy) < 0.01f) {
            zx = event.getAxisValue(MotionEvent.AXIS_RX)
            zy = event.getAxisValue(MotionEvent.AXIS_RY)
        }
        val rt = max(event.getAxisValue(MotionEvent.AXIS_RTRIGGER), event.getAxisValue(MotionEvent.AXIS_GAS))
        val lt = max(event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_BRAKE))

        val now = SystemClock.uptimeMillis()
        if (now - lastMotionLog > 500 && (hypot(x, y) > 0.2f || hypot(zx, zy) > 0.2f || rt > 0.2f || lt > 0.2f)) {
            lastMotionLog = now
            log("axes L(%.1f,%.1f) R(%.1f,%.1f) LT %.1f RT %.1f".format(x, y, zx, zy, lt, rt))
        }
        if (!active()) return
        lx = x; ly = y; rx = zx; ry = zy
        setAxisKey(Config.AXIS_R_TRIGGER, rt > 0.5f)
        setAxisKey(Config.AXIS_L_TRIGGER, lt > 0.5f)
        pump()
    }

    private fun setAxisKey(code: Int, down: Boolean) { if (down) pressed.add(code) else pressed.remove(code) }

    // ---------- gesture loop ----------

    private fun releaseAll() {
        pressed.clear(); lx = 0f; ly = 0f; rx = 0f; ry = 0f
    }

    private fun resetSlots() {
        for (s in listOf(moveSlot, lookSlot) + btnSlots.values) { s.stroke = null; s.end = null }
        lookAnchor = null
    }

    private fun pump() {
        if (inFlight) return
        val g = build() ?: return
        inFlight = true
        val my = ++gen
        handler.removeCallbacks(watchdog)
        handler.postDelayed(watchdog, 250)
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                if (my != gen) return
                handler.removeCallbacks(watchdog); inFlight = false; pump()
            }
            override fun onCancelled(d: GestureDescription?) {
                if (my != gen) return
                handler.removeCallbacks(watchdog); resetSlots(); inFlight = false
                handler.postDelayed({ pump() }, 30)
            }
        }, handler)
        if (!ok) { handler.removeCallbacks(watchdog); inFlight = false; resetSlots() }
    }

    private fun px(p: Pt) = PointF(p.x * w, p.y * h)
    private fun clamp(p: PointF) = PointF(p.x.coerceIn(1f, w - 1), p.y.coerceIn(1f, h - 1))

    private fun path(from: PointF, to: PointF) = Path().apply {
        moveTo(from.x, from.y)
        if (from.x != to.x || from.y != to.y) lineTo(to.x, to.y)
    }

    /** One segment for a slot. target==null lifts the finger. */
    private fun seg(b: GestureDescription.Builder, s: Slot, target: PointF?, start: Long, dur: Long): Boolean {
        val old = s.stroke
        val oldEnd = s.end
        if (target == null) {
            if (old == null || oldEnd == null) return false
            b.addStroke(old.continueStroke(path(oldEnd, oldEnd), start, 8, false))
            s.stroke = null; s.end = null
            return true
        }
        val t = clamp(target)
        val st = if (old == null || oldEnd == null)
            StrokeDescription(path(t, t), start, dur, true)
        else
            old.continueStroke(path(oldEnd, t), start, dur, true)
        b.addStroke(st)
        s.stroke = st; s.end = t
        return true
    }

    private fun build(): GestureDescription? {
        val p = Config.prefs(this)
        val sens = p.getInt("sens", 50) / 100f
        val dz = p.getInt("dz", 10) / 100f
        val tick = 40L
        val b = GestureDescription.Builder()
        var n = 0

        val wanted = HashSet<Pt>()
        for (k in pressed) keyMap[k]?.let { wanted.add(it) }
        // Fire/ADS become the camera finger: holding the button while dragging aims AND shoots
        val anchor: Pt? = when {
            Config.FIRE in wanted -> Config.FIRE
            Config.ADS in wanted -> Config.ADS
            else -> null
        }
        val driven = HashSet(wanted)
        if (anchor != null) driven.remove(anchor)

        // Movement
        val lm = hypot(lx, ly)
        val mc = px(Config.MOVE_CENTER)
        val moveTarget = if (lm < dz) null else {
            val r = Config.MOVE_RADIUS_H * h * min(1f, lm)
            PointF(mc.x + lx / lm * r, mc.y + ly / lm * r)
        }
        if (seg(b, moveSlot, moveTarget, 0, tick)) n++

        // Look
        val rm = hypot(rx, ry)
        val stick = rm >= dz
        if (!stick && anchor == null) {
            if (seg(b, lookSlot, null, 0, tick)) n++
            lookAnchor = null
        } else {
            val center = px(anchor ?: Config.LOOK_CENTER)
            val radius = (if (anchor != null) Config.ANCHOR_DRAG_RADIUS_H else Config.LOOK_RADIUS_H) * h
            var start = 0L
            if (lookSlot.stroke != null && lookAnchor != anchor) {
                seg(b, lookSlot, null, 0, tick); n++; start = 8
            }
            val speed = if (stick)
                h * 0.02f * (0.2f + sens * 2f) * ((rm - dz) / (1f - dz)).coerceIn(0f, 1f).pow(1.6f)
            else 0f
            val ux = if (stick) rx / rm else 0f
            val uy = if (stick) ry / rm else 0f
            val cur = lookSlot.end ?: center
            var next = PointF(cur.x + ux * speed, cur.y + uy * speed)
            if (lookSlot.stroke != null && hypot(next.x - center.x, next.y - center.y) > radius) {
                seg(b, lookSlot, null, 0, tick); n++; start = 8
                next = PointF(center.x + ux * speed, center.y + uy * speed)
            }
            seg(b, lookSlot, next, start, tick - start); n++
            lookAnchor = anchor
        }

        // Other buttons
        for (pt in driven) {
            val s = btnSlots.getOrPut(pt) { Slot() }
            if (seg(b, s, px(pt), 0, tick)) n++
        }
        for ((pt, s) in btnSlots) if (pt !in driven && seg(b, s, null, 0, tick)) n++

        return if (n == 0) null else b.build()
    }
}
