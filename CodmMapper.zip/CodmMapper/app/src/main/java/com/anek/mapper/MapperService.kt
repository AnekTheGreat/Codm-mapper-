package com.anek.mapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.accessibility.AccessibilityEvent
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

class MapperService : AccessibilityService() {

    private class Slot {
        var stroke: StrokeDescription? = null
        var end: PointF? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val moveSlot = Slot()
    private val lookSlot = Slot()
    private val btnSlots = HashMap<Pt, Slot>()

    private var w = 1920f
    private var h = 1080f
    private var fgPackage: String? = null
    private var inFlight = false

    // stick state
    private var lx = 0f; private var ly = 0f
    private var rx = 0f; private var ry = 0f
    private val pressed = HashSet<Int>()

    private val keyMap: Map<Int, Pt> = mapOf(
        KeyEvent.KEYCODE_BUTTON_R2 to Config.FIRE,
        KeyEvent.KEYCODE_BUTTON_R1 to Config.FIRE,
        Config.AXIS_R_TRIGGER to Config.FIRE,
        KeyEvent.KEYCODE_BUTTON_L2 to Config.ADS,
        KeyEvent.KEYCODE_BUTTON_L1 to Config.ADS,
        Config.AXIS_L_TRIGGER to Config.ADS,
        KeyEvent.KEYCODE_BUTTON_A to Config.JUMP,
        KeyEvent.KEYCODE_BUTTON_B to Config.CROUCH,
        KeyEvent.KEYCODE_BUTTON_X to Config.RELOAD,
        KeyEvent.KEYCODE_BUTTON_Y to Config.SWAP
    )

    override fun onServiceConnected() {
        val dm = resources.displayMetrics
        w = max(dm.widthPixels, dm.heightPixels).toFloat()
        h = min(dm.widthPixels, dm.heightPixels).toFloat()
        if (Build.VERSION.SDK_INT >= 34) {
            serviceInfo = serviceInfo.apply { motionEventSources = InputDevice.SOURCE_JOYSTICK }
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == "com.android.systemui") return
        fgPackage = pkg
        if (!active()) releaseAll()
    }

    override fun onInterrupt() { releaseAll() }

    private fun active() =
        Config.prefs(this).getBoolean("enabled", true) && fgPackage in Config.CODM_PACKAGES

    // ---------- input ----------

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (!active()) return false
        if (e.keyCode !in keyMap) return false
        if (e.action == KeyEvent.ACTION_DOWN) pressed.add(e.keyCode)
        else if (e.action == KeyEvent.ACTION_UP) pressed.remove(e.keyCode)
        pump()
        return true // swallow so CODM's own controller support doesn't double-fire
    }

    // API 34+. Sticks arrive here as joystick motion events.
    override fun onMotionEvent(event: MotionEvent) {
        if (!active()) return
        if (event.source and InputDevice.SOURCE_JOYSTICK == 0) return
        lx = event.getAxisValue(MotionEvent.AXIS_X)
        ly = event.getAxisValue(MotionEvent.AXIS_Y)
        var zx = event.getAxisValue(MotionEvent.AXIS_Z)
        var zy = event.getAxisValue(MotionEvent.AXIS_RZ)
        if (hypot(zx, zy) < 0.01f) {
            zx = event.getAxisValue(MotionEvent.AXIS_RX)
            zy = event.getAxisValue(MotionEvent.AXIS_RY)
        }
        rx = zx; ry = zy
        setAxisKey(Config.AXIS_R_TRIGGER,
            max(event.getAxisValue(MotionEvent.AXIS_RTRIGGER), event.getAxisValue(MotionEvent.AXIS_GAS)) > 0.5f)
        setAxisKey(Config.AXIS_L_TRIGGER,
            max(event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_BRAKE)) > 0.5f)
        pump()
    }

    private fun setAxisKey(code: Int, down: Boolean) { if (down) pressed.add(code) else pressed.remove(code) }

    // ---------- gesture loop ----------

    private fun releaseAll() {
        pressed.clear(); lx = 0f; ly = 0f; rx = 0f; ry = 0f
    }

    private fun resetSlots() {
        for (s in listOf(moveSlot, lookSlot) + btnSlots.values) { s.stroke = null; s.end = null }
    }

    private fun pump() {
        if (inFlight) return
        val g = build() ?: return
        inFlight = true
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { inFlight = false; pump() }
            override fun onCancelled(d: GestureDescription?) { resetSlots(); inFlight = false; pump() }
        }, handler)
        if (!ok) { inFlight = false; resetSlots() }
    }

    private fun px(p: Pt) = PointF(p.x * w, p.y * h)
    private fun clamp(p: PointF) = PointF(p.x.coerceIn(1f, w - 1), p.y.coerceIn(1f, h - 1))

    private fun path(from: PointF, to: PointF) = Path().apply {
        moveTo(from.x, from.y)
        if (from.x != to.x || from.y != to.y) lineTo(to.x, to.y)
    }

    /** Add one segment for a slot. target==null means finger should lift. Returns true if a stroke was added. */
    private fun seg(b: GestureDescription.Builder, s: Slot, target: PointF?, start: Long, dur: Long): Boolean {
        val old = s.stroke
        val oldEnd = s.end
        if (target == null) {
            if (old == null || oldEnd == null) return false
            b.addStroke(old.continueStroke(path(oldEnd, oldEnd), start, 8, false))
            s.stroke = null; s.end = null
            return true
        }
        val t = clamp(target)
        val st = if (old == null || oldEnd == null)
            StrokeDescription(path(t, t), start, dur, true)
        else
            old.continueStroke(path(oldEnd, t), start, dur, true)
        b.addStroke(st)
        s.stroke = st; s.end = t
        return true
    }

    private fun build(): GestureDescription? {
        val p = Config.prefs(this)
        val sens = p.getInt("sens", 50) / 100f
        val dz = p.getInt("dz", 10) / 100f
        val tick = 40L
        val b = GestureDescription.Builder()
        var n = 0

        // Movement: finger offset from joystick center, proportional to deflection
        val lm = hypot(lx, ly)
        val mc = px(Config.MOVE_CENTER)
        val moveTarget = if (lm < dz) null else {
            val r = Config.MOVE_RADIUS_H * h * min(1f, lm)
            PointF(mc.x + lx / lm * r, mc.y + ly / lm * r)
        }
        if (seg(b, moveSlot, moveTarget, 0, tick)) n++

        // Look: integrate stick into finger position inside the zone; re-center when it hits the edge
        val rm = hypot(rx, ry)
        val lc = px(Config.LOOK_CENTER)
        val lookR = Config.LOOK_RADIUS_H * h
        if (rm < dz) {
            if (seg(b, lookSlot, null, 0, tick)) n++
        } else {
            val mag = ((rm - dz) / (1f - dz)).coerceIn(0f, 1f).pow(1.6f)
            val speed = h * 0.02f * (0.2f + sens * 2f) * mag
            val cur = lookSlot.end ?: lc
            val next = PointF(cur.x + rx / rm * speed, cur.y + ry / rm * speed)
            if (hypot(next.x - lc.x, next.y - lc.y) > lookR && lookSlot.stroke != null) {
                // lift old finger, drop a new one at center, continue same tick
                seg(b, lookSlot, null, 0, tick)
                val s2 = PointF(lc.x + rx / rm * speed, lc.y + ry / rm * speed)
                seg(b, lookSlot, s2, 8, tick - 8)
                n += 2
            } else {
                seg(b, lookSlot, next, 0, tick); n++
            }
        }

        // Buttons: held while any mapped key is down
        val wanted = HashSet<Pt>()
        for (k in pressed) keyMap[k]?.let { wanted.add(it) }
        for (pt in wanted) {
            val s = btnSlots.getOrPut(pt) { Slot() }
            if (seg(b, s, px(pt), 0, tick)) n++
        }
        for ((pt, s) in btnSlots) if (pt !in wanted && seg(b, s, null, 0, tick)) n++

        return if (n == 0) null else b.build()
    }
}
