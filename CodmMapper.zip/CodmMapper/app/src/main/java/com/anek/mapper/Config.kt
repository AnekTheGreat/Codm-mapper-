package com.anek.mapper

import android.content.Context

/** Positions are fractions of the landscape screen (x of width, y of height). EDIT THESE to match your CODM HUD. */
data class Pt(val x: Float, val y: Float)

object Config {
    val CODM_PACKAGES = setOf(
        "com.activision.callofduty.shooter",
        "com.garena.game.codm",
        "com.tencent.tmgp.cod"
    )

    // Left stick -> movement joystick
    val MOVE_CENTER = Pt(0.14f, 0.70f)
    const val MOVE_RADIUS_H = 0.10f      // fraction of screen height

    // Right stick -> camera drag zone (empty area on the right half of the screen)
    val LOOK_CENTER = Pt(0.60f, 0.38f)
    const val LOOK_RADIUS_H = 0.20f
    const val ANCHOR_DRAG_RADIUS_H = 0.30f // drag room when look is anchored to fire/ADS button

    // Buttons
    val FIRE = Pt(0.86f, 0.60f)
    val ADS = Pt(0.80f, 0.44f)
    val JUMP = Pt(0.93f, 0.42f)
    val CROUCH = Pt(0.93f, 0.28f)
    val RELOAD = Pt(0.70f, 0.82f)
    val SWAP = Pt(0.62f, 0.82f)

    // Fake keycodes for analog triggers
    const val AXIS_R_TRIGGER = -1
    const val AXIS_L_TRIGGER = -2

    fun prefs(c: Context) = c.getSharedPreferences("mapper", Context.MODE_PRIVATE)
}
